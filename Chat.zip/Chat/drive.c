#include<linux/module.h>
#include<linux/init.h>
#include<linux/fs.h>
#include<asm/uaccess.h>
#include<linux/wait.h>
#include<linux/semaphore.h>
#include<linux/sched.h>
#include<linux/cdev.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include<linux/types.h>
#include<linux/kdev_t.h>
#include<linux/device.h>
#include <linux/uaccess.h>

#define MAXLEN 3000
#define MAJOR_NUM 456//主设备号，没有被使用
#define MAXNUM 10//最多的设备数
#define MINOR_NUM 0

struct Scull_Dev {
    struct cdev drive;//字符设备
    /*struct semaphore sem;//信号量，实现读写时的PV操作
    wait_queue_head_t outq;//等待队列，实现阻塞操作
    int flag;//阻塞唤醒标志*/
    unsigned char *buffer;
    int npos;
}*driver[MAXNUM];

static ssize_t drive_read(struct file *filp,char *buf,size_t len,loff_t* off)
{
    struct Scull_Dev* pdb=filp->private_data;
    /*if(wait_event_interruptible(pdb->outq,pdb->flag!=0))//不可读时 阻塞读进程
    {
        return -ERESTARTSYS;
    }
    
    pdb->flag=0;*/
    //printk("into the read function\n");
    //printk("the rd is %c\n",*globalvar.rd);
    int nlen=len;
    if(nlen>pdb->npos-*off)
        nlen=pdb->npos-*off;
    //printk("the len is %d\n",nlen);
    if(copy_to_user(buf, (pdb->buffer)+*off, nlen))//使用copy_to_user ()函数从driver读数据到user
    {
        //printk(KERN_ALERT"copy failed\n");
        //up(&pdb->sem);
        return -EFAULT;
    }
    //printk("the read buffer is %s\n",globalvar.buffer);
    /*up(&pdb->sem);//V操作*/
    *off += nlen;
    return nlen;
}

static ssize_t drive_write(struct file *filp, const char * buf, size_t len, loff_t* off)
{
    int nlen=len;
    struct Scull_Dev* pdb=filp->private_data;
     /*if(down_interruptible(&pdb->sem))//P操作
    {
        return -ERESTARTSYS;
    }*/
    if(nlen>MAXLEN-pdb->npos)
        nlen=MAXLEN-pdb->npos;
    if(nlen==0)
        return -ENOMEM;
    if(copy_from_user(&pdb->buffer[pdb->npos], buf, nlen))
    {
       /* up(&pdb->sem);//V操作*/
        return -EFAULT;
    }
    pdb->npos += nlen;
    /*up(&pdb->sem);//V操作
    pdb->flag=1;//条件成立，可以唤醒读进程
    wake_up_interruptible_all(&pdb->outq);*/
    return nlen;
}

static int drive_open(struct inode *inode, struct file * filp)
{
    int nminor=iminor(inode);
    if(!driver[nminor]->buffer)
        driver[nminor]->buffer=(unsigned char *)vmalloc(MAXLEN);
    if(!driver[nminor]->buffer)
        return -ENOMEM;
    filp->private_data=driver[nminor];
    if((filp->f_flags&O_ACCMODE)==O_WRONLY)
        driver[nminor]->npos=0;
    return 0;
}

static int drive_release(struct inode* inode, struct file* filp)
{

    int i;
    for(i=0; i<MAXNUM; ++i){
        cdev_del(&driver[i]->drive);
        if(driver[i]->buffer)
            vfree(driver[i]->buffer);
        kfree(driver[i]);
    }
  
  return 0;
}

struct file_operations fops = {
    .owner=THIS_MODULE,
    .read=drive_read,
    .write=drive_write,
    .open=drive_open,
    .release=drive_release,
};

static int char_init(void)
{
    int i, ndev, ret;
    printk(KERN_INFO "Loading " KBUILD_MODNAME "...\n");
    for(i=0; i<MAXNUM; ++i) {
        driver[i] =(struct Scull_Dev*)kmalloc(sizeof(*driver[0]), GFP_KERNEL);
        if(!driver[i]){
            printk(KERN_EMERG "Can't allocate memory to mydata\n");
            return -ENOMEM;
        }
        driver[i]->buffer=NULL;
        driver[i]->npos=0;
        cdev_init(&driver[i]->drive, &fops);
        driver[i]->drive.owner=THIS_MODULE;
        ndev=MKDEV(MAJOR_NUM, MINOR_NUM+i);
        ret=cdev_add(&driver[i]->drive, ndev,1);
        if(ret){
            printk(KERN_EMERG "Can't register device[%d]!\n", i);
            return -1;
        }
    }
    return 0;
}

static void drive_exit(void)
{
    int i;
    printk(KERN_INFO "Unloading " KBUILD_MODNAME "...\n");
    for(i=0; i<MAXNUM; ++i){
        cdev_del(&driver[i]->drive);
        if(driver[i]->buffer)
            vfree(driver[i]->buffer);
        kfree(driver[i]);
    }
}

module_exit(drive_exit);
module_init(char_init);
MODULE_LICENSE("GPL");






