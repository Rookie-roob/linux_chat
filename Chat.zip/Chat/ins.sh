sudo insmod ./drive.ko  
lsmod | grep drive  
sudo mknod /dev/drive0 c 456 0  
sudo mknod /dev/drive1 c 456 1
sudo mknod /dev/drive2 c 456 2
sudo mknod /dev/drive3 c 456 3
sudo mknod /dev/drive4 c 456 4
sudo mknod /dev/drive5 c 456 5
sudo mknod /dev/drive6 c 456 6
sudo mknod /dev/drive7 c 456 7
sudo mknod /dev/drive8 c 456 8
sudo mknod /dev/drive9 c 456 9
sudo chmod 666 /dev/drive*
