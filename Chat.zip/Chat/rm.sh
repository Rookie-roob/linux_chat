sudo rm /dev/drive0
sudo rm /dev/drive1
sudo rm /dev/drive2
sudo rm /dev/drive3
sudo rm /dev/drive5
sudo rm /dev/drive6
sudo rm /dev/drive7
sudo rm /dev/drive8
sudo rm /dev/drive9

sudo rmmod drive
dmesg  | tail -1 
