//chat.c  聊天程序

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <memory.h>
#include <unistd.h>
#include <termios.h>

int inword(void);

int main()
{
    int fd,i=0;
    char msg[3001];
    fd=open("/dev/drive0", O_RDWR|O_APPEND);
    if(fd==-1){
        fprintf(stderr, "can't openfile drive0\n");
        exit(0);
    }

    

    while(1){
       
	if( inword() ) 
	{
	   char ch[3000]; //存放字符
	   char mes[200]; //存放写入的信息
	   int pid = getpid();
	   fgets(ch,3000,stdin);
           sprintf(mes,"%s",ch);
           write(fd,mes,strlen(mes));
        }

         for(i=0;i<3001;i++)
             msg[i]='\0';
          
          read(fd,msg,3000);
          if(strlen(msg) != 0 ) { //判断是不是有新数据
            printf("%s\n",msg);         
          }
/*
          if(strcmp(msg,"quit")==0)
            {
                //close(fd);
                break;
            }
*/         
          sleep(1.5);
    }
    close(fd);
    return 0;
}

//非阻塞检测按键函数
int inword(void)
{ 
	struct termios oldt, newt;
	int ch,oldf; 
	tcgetattr(STDIN_FILENO, &oldt);
	newt=oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf=fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

	  ch=getchar();
	  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	  fcntl(STDIN_FILENO, F_SETFL, oldf);
	  if(ch != EOF) { 
	     ungetc(ch, stdin);
	     return 1;
	  } 
    return 0;
}


